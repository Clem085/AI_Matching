
import random
from pathlib import Path
import pandas as pd

random.seed(7)

STATES = ["NC","SC","VA","GA","FL","TX","CA","NY","PA","OH"]
LICENSES = ["LCSW","LMFT","LPC","LMHC","LPCC","LMSW"]
DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat"]
SLOTS = ["AM","PM","Eve"]

def random_name():
    first = random.choice(["Alex","Sam","Jordan","Taylor","Morgan","Casey","Riley","Avery","Jamie","Cameron","Drew","Quinn"])
    last  = random.choice(["Lee","Kim","Patel","Garcia","Nguyen","Hernandez","Chen","Brown","Davis","Wilson","Moore","Clark"])
    return f"{first} {last}"

def random_email(name):
    base = name.lower().replace(' ', '.')
    dom = random.choice(['example.com','sample.org','mail.net'])
    return f"{base}@{dom}"

def random_availability(k=3):
    picks = random.sample([(d,t) for d in DAYS for t in SLOTS], k=k)
    return ', '.join([f"{d} {t}" for d,t in picks])

def generate_supervisors(n=60):
    rows = []
    for i in range(n):
        name = random_name()
        rows.append({
            'Timestamp': '',
            'Email Address': random_email(name),
            'Name': name,
            'State': random.choice(STATES),
            'Who can you supervise?': ', '.join(random.sample(LICENSES, k=random.randint(1,3))),
            'Availability': random_availability(k=random.randint(3,6)),
            'Capacity': random.randint(1,4)
        })
    return pd.DataFrame(rows)

def generate_associates(n=140):
    rows = []
    for i in range(n):
        name = random_name()
        rows.append({
            'Timestamp': '',
            'Email Address': random_email(name),
            'Name': name,
            'State': random.choice(STATES),
            'License Type': random.choice(LICENSES),
            'Availability': random_availability(k=random.randint(2,5)),
        })
    return pd.DataFrame(rows)

def main(out_dir='.'):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    sup = generate_supervisors()
    assoc = generate_associates()
    sup.to_csv(out/'Supervision_Supervisors_SYNTH.csv', index=False)
    assoc.to_csv(out/'Supervision_Associates_SYNTH.csv', index=False)
    print('Wrote synthetic supervisors & associates.')

if __name__ == '__main__':
    main()
